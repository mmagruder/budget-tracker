import os
from datetime import datetime

DATA_FILE = "data.txt"

def load_transactions():
    if not os.path.exists(DATA_FILE):
        return []

    with open(DATA_FILE, "r") as file:
        lines = file.readlines()
    return [line.strip() for line in lines]

def save_transaction(entry):
    with open(DATA_FILE, "a") as file:
        file.write(f"{entry}\n")

def get_balance(transactions):
    balance = 0.0
    for entry in transactions:
        parts = entry.split(" | ")
        if len(parts) >= 2:
            amount = float(parts[1])
            if parts[0] == "Income":
                balance += amount
            elif parts[0] == "Expense":
                balance -= amount
    return balance

def display_menu():
    print("\n===== Personal Budget Tracker =====")
    print("1. Add Income")
    print("2. Add Expense")
    print("3. View Balance")
    print("4. View Transaction History")
    print("5. Exit")

def main():
    transactions = load_transactions()

    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == "1":
            amount = input("Enter income amount: $")
            try:
                amount = float(amount)
                entry = f"Income | {amount:.2f} | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                transactions.append(entry)
                save_transaction(entry)
                print("Income added!")
            except ValueError:
                print("Invalid amount. Try again.")
        elif choice == "2":
            amount = input("Enter expense amount: $")
            try:
                amount = float(amount)
                entry = f"Expense | {amount:.2f} | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                transactions.append(entry)
                save_transaction(entry)
                print("Expense added!")
            except ValueError:
                print("Invalid amount. Try again.")
        elif choice == "3":
            balance = get_balance(transactions)
            print(f"Current Balance: ${balance:.2f}")
        elif choice == "4":
            if transactions:
                print("\n--- Transaction History ---")
                for t in transactions:
                    print(t)
            else:
                print("No transactions yet.")
        elif choice == "5":
            print("Goodbye! Data saved.")
            break
        else:
            print("Invalid choice. Please select 1–5.")

if __name__ == "__main__":
    main()