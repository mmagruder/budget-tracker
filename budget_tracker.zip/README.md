# Personal Budget Tracker (CLI App)

A simple Python-based budget tracker that lets you:
- Add income and expenses
- View current balance
- View full transaction history
- Save data locally to a file

## How to Run

```bash
python budget.py
```

Your data will be saved automatically to `data.txt`.

## Features
- Console menu for interaction
- Timestamped transactions
- Persistent storage with local file